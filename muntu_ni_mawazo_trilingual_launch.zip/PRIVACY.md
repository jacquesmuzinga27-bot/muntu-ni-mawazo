# Muntu ni Mawazo — Privacy, consent and moderation policy
*Starter policy template. Review and adapt it to the laws and needs of the countries where the website operates before launch.*

## Our purpose
Muntu ni Mawazo shares positive experiences, life stories, lessons learned, kindness and hope.

## Submission and publication
- Sending a story does not guarantee publication.
- An editor should review submissions for relevance, respectful language, safety, privacy, and possible defamation before publishing.
- Do not publish a submitter's story publicly until the site owner has configured a secure submission channel and reviewed the required consent.
- Keep an internal record of publication permission and the date of approval.
- Provide a way for a contributor to request correction or removal.

## Personal information and consent
- Ask contributors not to include home addresses, phone numbers, identity numbers, financial information, medical details, or other sensitive information.
- Obtain permission before identifying another person or using their photo, words, or personal story.
- Do not accept content that threatens, harasses, exposes, or targets private individuals.
- If stories involving children are accepted, establish a separate guardian-consent process before collecting or publishing them.

## Data handling
- Collect only the information needed to review and publish a story.
- Limit access to submissions to trusted editors.
- Do not promise confidentiality unless the submission system and editorial process can actually provide it.
- Set a retention period and delete submissions that are no longer needed.
- Publish a contact address and a clear privacy notice before collecting public submissions.

## Editorial standards
We may edit for spelling, readability, length, translation, and privacy while preserving the author's meaning. Material may be declined if it is abusive, discriminatory, misleading, unlawful, promotional spam, or unrelated to the purpose of the community. We should contact authors when substantial edits are needed.

## Important launch note
The included website is a static front-end. Its sample submission form currently previews a story in the visitor's browser and does **not** send the story to the site owner or store it on a server. Connect and test a submission service (for example, a public Google Form that records responses in a private spreadsheet) before inviting the public to submit. Review each submission manually before publication.
