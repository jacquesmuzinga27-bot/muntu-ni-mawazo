MUNTU NI MAWAZO — TRILINGUAL LAUNCH STARTER
Languages: English, French, Swahili
Launch approach: free static hosting + moderated submissions

FILES
- index.html: responsive trilingual site. Language selector changes the interface and sample stories.
- PRIVACY.md: starter privacy/consent/moderation policy. Review before publishing.

IMPORTANT FUNCTIONAL LIMITATION
The story form currently creates a browser-only preview. It does not transmit, store, or email submissions. This is intentional so the page does not pretend that a submission was delivered. Before inviting the public, connect a public submission form (recommended starter: Google Forms) and manually review stories before adding them to the site.

LOW-COST / FREE-FIRST LAUNCH PLAN
1. Create or sign in to a GitHub account.
2. Create a PUBLIC repository named `muntu-ni-mawazo` (GitHub Pages on GitHub Free requires a public repository).
3. Upload `index.html` and `PRIVACY.md` to the repository root.
4. Open repository Settings > Pages. Select deployment from the `main` branch and `/ (root)`, then save. Wait for the published `https://YOUR-USERNAME.github.io/muntu-ni-mawazo/` URL.
5. Create a Google Form with these fields: preferred name or pen name (optional), language of story, category, title, story, permission/consent checkbox, and confirmation that no private third-party information is included.
6. Publish the form for anyone with the link. Link responses to a private Google Sheet. Do not share the response spreadsheet publicly. If possible, set notifications for new responses. Google Forms supports publishing, collecting responses, and embedding the form into a website.
7. Update the website's Share your story section to link to the Google Form (or embed its published form HTML). Remove/disable the demo form to avoid confusing visitors. Test the complete flow in a private/incognito browser before announcing.
8. Review each submission, request edits/permission where needed, then manually add approved stories to `index.html`. Do not publish unreviewed submissions.
9. Publish the privacy/moderation policy, a contact email, and an editorial removal/correction process.
10. When ready, register `muntunimawazo.com` if available and connect it under GitHub repository Settings > Pages > Custom domain. A custom domain registration normally costs money; the GitHub Pages subdomain can be used initially at no hosting charge. Follow the current official GitHub Pages domain instructions.

GITHUB PAGES
Official guide: https://docs.github.com/en/pages
Custom domain guide: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

GOOGLE FORMS
Official instructions to publish and collect responses: https://support.google.com/a/users/answer/9303072?hl=en
Official instructions to embed a form: https://support.google.com/docs/answer/2839588?hl=en

EDITORIAL CHECKLIST BEFORE APPROVAL
- Does the contributor own the story or have permission to share it?
- Are names, photos and identifying details shared with consent?
- Does it avoid harassment, hate, threats, private data, defamatory claims and dangerous misinformation?
- Is the author's intended meaning preserved in editing/translation?
- Has the author agreed to public display and translation, where applicable?
- Is there a way to contact the editor for correction/removal?

DOMAIN NOTE
The requested domain `www.muntunimawazo.com` is not connected by these files. Domain availability and ownership have not been checked. Hosting/publishing and DNS configuration must be completed separately.
